
/*
Tendo uma lista ligada.
Fazer uma fun��o para inverter a lista.

void InverterLista(Lista *L)
{
    if (!L) return;
    if (!L->Inicio) return;
    NO *P = L->Inicio;
    NO *Ant = NULL;
    NO *S = NULL;
    while (P)
    {
        S = P->Prox;
        P->Prox = Ant;
        Ant = P;
        P = S;
    }
    L->Inicio = Ant;
}


MostrarLista(LP);
InverterLista(LP);
MostrarLista(LP);
InverterLista(LP);

REmover o primeiro

void RemoverInicio(Lista *L)
{
    if (!L) return;
    if (!L->Inicio) return;
    NO *P = L->Inicio->Prox;
    Destruir(L->Inicio);
    L->Inicio = P;
    L->Nel--;
}


*/

